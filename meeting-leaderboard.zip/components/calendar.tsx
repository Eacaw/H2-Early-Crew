"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { format, startOfWeek, endOfWeek, eachDayOfInterval, addWeeks, subWeeks, isToday } from "date-fns"
import { cn } from "@/lib/utils"

export function Calendar({ meetings, isAdmin, onAddMeeting }) {
  const [currentDate, setCurrentDate] = useState(new Date())
  const [currentWeek, setCurrentWeek] = useState([])
  const [timeSlots, setTimeSlots] = useState([])

  useEffect(() => {
    // Generate days for the current week
    const start = startOfWeek(currentDate, { weekStartsOn: 0 }) // Sunday
    const end = endOfWeek(currentDate, { weekStartsOn: 0 }) // Saturday
    const days = eachDayOfInterval({ start, end })
    setCurrentWeek(days)

    // Generate time slots from 8 AM to 6 PM
    const slots = []
    for (let hour = 8; hour <= 18; hour++) {
      slots.push(hour)
    }
    setTimeSlots(slots)
  }, [currentDate])

  const nextWeek = () => {
    setCurrentDate(addWeeks(currentDate, 1))
  }

  const prevWeek = () => {
    setCurrentDate(subWeeks(currentDate, 1))
  }

  const formatTimeSlot = (hour) => {
    return format(new Date().setHours(hour, 0, 0, 0), "h:mm a")
  }

  const getMeetingsForTimeSlot = (day, hour) => {
    const dayStart = new Date(day)
    dayStart.setHours(hour, 0, 0, 0)

    const dayEnd = new Date(day)
    dayEnd.setHours(hour, 59, 59, 999)

    return meetings.filter((meeting) => {
      const meetingDate = new Date(meeting.startTime)
      return meetingDate >= dayStart && meetingDate <= dayEnd
    })
  }

  const handleTimeSlotClick = (day, hour) => {
    if (isAdmin) {
      const selectedDate = new Date(day)
      selectedDate.setHours(hour, 0, 0, 0)
      onAddMeeting(selectedDate, hour)
    }
  }

  return (
    <Card className="overflow-hidden">
      <div className="flex items-center justify-between p-4 border-b">
        <h2 className="font-semibold">
          {format(currentWeek[0], "MMMM d")} - {format(currentWeek[6], "MMMM d, yyyy")}
        </h2>
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="icon" onClick={prevWeek}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon" onClick={nextWeek}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <CardContent className="p-0">
        <div className="grid grid-cols-8 border-b">
          {/* Time column header */}
          <div className="border-r p-2 text-center text-xs font-medium text-muted-foreground">Time</div>

          {/* Day headers */}
          {currentWeek.map((day) => (
            <div
              key={day.toString()}
              className={cn("p-2 text-center border-r last:border-r-0", isToday(day) && "bg-green-900/20")}
            >
              <div className="text-xs font-medium text-muted-foreground">{format(day, "EEE")}</div>
              <div className={cn("text-sm font-semibold", isToday(day) && "text-green-600")}>{format(day, "d")}</div>
            </div>
          ))}
        </div>

        <div className="overflow-auto max-h-[600px]">
          {/* Time slots */}
          {timeSlots.map((hour) => (
            <div key={hour} className="grid grid-cols-8 border-b last:border-b-0">
              {/* Time column */}
              <div className="border-r p-2 text-xs font-medium text-muted-foreground flex items-center justify-center">
                {formatTimeSlot(hour)}
              </div>

              {/* Day cells */}
              {currentWeek.map((day) => {
                const meetingsInSlot = getMeetingsForTimeSlot(day, hour)

                return (
                  <div
                    key={day.toString()}
                    className={cn(
                      "border-r last:border-r-0 p-1 min-h-[60px]",
                      isAdmin && "cursor-pointer hover:bg-muted/50",
                      isToday(day) && "bg-green-50/50",
                    )}
                    onClick={() => handleTimeSlotClick(day, hour)}
                  >
                    {meetingsInSlot.map((meeting) => (
                      <div
                        key={meeting.id}
                        className="bg-green-900/30 text-green-300 p-1 text-xs rounded mb-1 overflow-hidden text-ellipsis"
                      >
                        {meeting.meetingName}
                      </div>
                    ))}
                  </div>
                )
              })}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
